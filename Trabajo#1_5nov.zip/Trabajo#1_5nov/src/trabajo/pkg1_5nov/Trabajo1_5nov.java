/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabajo.pkg1_5nov;

import java.util.Scanner;

/**
 *
 * @author Carmen
 */
public class Trabajo1_5nov {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int ventas,costototal = 0;
        while(true){
        System.out.println("Ingrese el número de ventas a introducir 🛒 : ");
        ventas=entrada.nextInt();
        
        
        if (ventas > 0){
            break;
        } 
        else{
            System.out.println("Favor ingrese números positivos únicamente");
        }
        }
           
        for (int i =0 ; i < ventas; i++) {
            System.out.println("Favor ingresar el precio de la venta "+(i+1)+":");
            int costoventa =entrada.nextInt();
            costototal+=costoventa;
        }
           
        System.out.println("EL costo de todas las ventas es 🎀:"+costototal);
        }
        
        
    }
    

